import React from 'react'

function Account() {
  return (
    <div className='w-full h-screen bg-[#1a1a1a] text-white flex justify-center items-center'>
      <h2 className='text-3xl'>ACCOUNT</h2>
    </div>
  )
}

export default Account