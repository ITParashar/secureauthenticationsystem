import React from 'react'

function Home() {
  return (
    <div className='w-full h-screen bg-[#1a1a1a] text-white flex justify-center items-center'>
      <h2 className='text-3xl'>HOME</h2>
    </div>
  )
}

export default Home